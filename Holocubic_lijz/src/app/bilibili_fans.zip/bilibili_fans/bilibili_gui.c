#include "bilibili_gui.h"

#include "lv_port_indev.h"
#include "lvgl.h"

void bilibili_gui_init(void)
{

}


/*
 * 其他函数请根据需要添加
 */

void display_bilibili(const char *file_name, lv_scr_load_anim_t anim_type)
{

}

void bilibili_gui_del(void) 
{

}