#ifndef APP_BILIBILI_H
#define APP_BILIBILI_H

#include "../sys/interface.h"

extern APP_OBJ bilibili_app;

#endif